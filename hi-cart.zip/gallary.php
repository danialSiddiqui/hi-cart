<?php include './includes/header.php'; ?>

<div id="service-banner">
  <div class="rgb">
  <div class="container">

      <div class="row">
          <div class="col-lg-12">
             <div class="about-hd">
               <h1>Gallery</h1>
             </div><!--about-hd-->
           </div><!--col-lg-12-->
      </div><!--row-->
    </div><!--container-->
 </div>
 </div>

<div id="banner-pgn">
  <div class="container">

      <div class="row">
          <div class="col-lg-3">
             <div class="bnr-shrt">
              <ul>
               <li><a href="http://lachaicart.com/">Home <span> &gt; </span> </a></li>
               <li><a href="http://lachaicart.com/home/gallery">Gallery</a></li>
              </ul>
             </div><!--abt-hd-->
           </div><!--col-lg-12-->
      </div><!--row-->
    </div><!--container-->

 </div>

 <?php include './includes/footer.php'; ?>