<?php include './includes/header.php'; ?>
<div id="team-banner">
  <div class="rgb">
  <div class="container">

      <div class="row">
          <div class="col-lg-12">
             <div class="about-hd">
               <h1>DIY &amp; MORE</h1>
             </div><!--about-hd-->
           </div><!--col-lg-12-->
      </div><!--row-->
    </div><!--container-->
 </div>
 </div>


<div id="banner-pgn">
  <div class="container">

      <div class="row">
          <div class="col-lg-3">
             <div class="bnr-shrt">
              <ul>
               <li><a href="http://lachaicart.com/">Home <span> &gt; </span> </a></li>
               <li><a href="http://lachaicart.com/home/diy_and_more">DIY &amp; MORE</a></li>
              </ul>
             </div><!--abt-hd-->
           </div><!--col-lg-12-->
      </div><!--row-->
    </div><!--container-->
 </div>



<div id="main-blog">
  <div class="container">

   <div class="row">

            <div class="col-lg-6 col-md-6 offset-md-3">
            <div class="prpose-mian">
                <div class="prp-bg">
                 <p>Pickup Items</p>
                </div>
             <div class="prp-img">
                <img src="http://lachaicart.com/assets/images/img-6.jpg">
              <div class="prpose-inner">
              <div class="prp-txt-one">
                <div class="w-100 float">
             </div>
             </div><!--prp-txt-one-->
            </div><!--prapose-inner-->
           </div><!--prp-img-->

           <div class="prp-btn">
             <a href="http://lachaicart.com/home/cart_detail/PICKUPCART">more details</a>
           </div>

           </div><!--prpose-mian-->
          </div><!--col-4-->

    </div><!--container-->
 </div><!--main-blog-->
 </div>

 <?php include './includes/footer.php'; ?>